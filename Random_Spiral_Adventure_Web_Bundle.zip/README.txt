Random Spiral Adventure Web Bundle

Contents:
- index.html: Promotional page with demo
- random_spiral_game.html: Playable game prototype
- assets/: Folder for mockup images (screenshots.png, etc.)
- style.css (optional): external styles

Instructions:
1. Keep all files and assets together.
2. Open index.html in browser to view promo page.
3. Edit asset paths if needed.
4. Host folder on any web server (GitHub Pages, Netlify, Vercel).
